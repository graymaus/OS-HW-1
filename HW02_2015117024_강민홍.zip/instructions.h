
int pwd(); 
int ls();
int ls_a();
int ls_l();
int ls_al();
int ls_t();
int ls_rt();
